using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }



        
        [HttpPost]
        public IActionResult Contact(string name, string email, string message)
        {
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(message))
            {
                TempData["Alert"] = "All fields are required!";
                return View();
            }

            if (name == "Shary" && email == "malikshaharyar735@gmail.com")
            {
                ViewData["Response"] = "Login Successfully";
                TempData["FormSubmitted"] = message; 
            }
            else
            {
                TempData["Alert"] = "Wrong Email";
                ViewData["Response"] = "Please try again.";
            }

            return View();
        }


        public IActionResult blogs()
        {
            return View();
        }
        public IActionResult mail()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
